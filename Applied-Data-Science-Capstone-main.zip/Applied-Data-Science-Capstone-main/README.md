# Applied Data Science Capstone project
Challenge:

A company named Space Y asked us to:

1.determine the price of each launch

2.gather public information about Space X and 

3.create dashboards for the team train a machine learning model to predict successful Stage 1 recovery.

This repository contains completed notebooks and python files for the capstone project : IBM Data Science Professional Certification.

Week 1

Capstone Introduction and Understanding the Datasets

Collecting the Data:

Data Wrangling:

Week 2

Exploratory Analysis Using SQL

Exploratory Analysis Using Pandas and Matplotlib

Week 3

Interactive Visual Analytics and Dashboard

Week 4

Predictive Analysis (Classification)

Week 5

Final Presentation
